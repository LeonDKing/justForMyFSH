/**
 * Created by LeonDKing on 2016/1/3.
 */
define( [ 'common' ], function () {

})